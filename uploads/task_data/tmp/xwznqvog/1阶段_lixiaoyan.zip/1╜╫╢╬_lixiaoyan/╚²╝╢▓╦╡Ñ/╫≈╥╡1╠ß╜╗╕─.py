name = "lixiaoyan"
passwd = "123"
va=1



for i in range(10):
    if i < 3:
        nam = input("输入用户名:")
        pwd = input("输入密码:")
        if name == nam and passwd == pwd:
            login = 1
            break
        else:
            print("用户名或密码错误，请重试")
            login = 2

f=open("三级.txt","r")
tmp_list=[]
for line in f:
    tmp=line.strip()        #脱掉换行符
    tmp_list.append(tmp)
f.close()

city=tmp_list[0].split(",")
city1=tmp_list[1].split(",")
city2=tmp_list[2].split(",")
beijing1=tmp_list[3].split(",")
beijing2=tmp_list[4].split(",")
shanghai1=tmp_list[5].split(",")
shanghai2=tmp_list[6].split(",")

if login == 1:
    print("欢迎登陆",nam,"!")

    a = 0  # 主菜单
    while va == 1:
        if a == 0:  # 显示主菜单
            print("\n".join(city))  #将列表内的元素进行拼接，并换行输出
            f.close()
            b = input("选择城市列表:")  # 记录二级菜单选项
            if b == "1":
                a = 1  # 北京/二级菜单
            elif b == "2":
                a = 10  # 上海/二级菜单
            elif b == "q":
                print("退出")
                exit()
            else:
                print("请输入正确选项")
                a = 0
        elif a == 1:  # 输出北京菜单
            print("\n".join(city1))
            f.close()
            b = input("选择区列表:")
            if b == "1":
                a = 2  # 崇文
            elif b == "2":
                a = 3  # 宣武
            elif b == "b":
                a = 0  # 返回主菜单
            elif b == "q":
                exit()
            else:
                print("请输入正确选项:")
                a = 1
        elif a == 2:  # 崇文
            print("\n".join(beijing1))
            f.close()
            b = input("已到3级菜单请输入b/q:")
            if b == "b":
                a = 1
            elif b == "q":
                exit()
            else:
                print("请输入正确选项:")
                a = 2
        elif a == 3:  # 宣武
            print("\n".join(beijing2))
            f.close()
            b = input("已到3级菜单请输入b/q:")
            if b == "b":
                a = 1  # 返回
            elif b == "q":
                exit()
            else:
                print("请输入正确选项:")
                a = 3
                ###############################
        elif a == 10:  # 输出上海菜单
            print("\n".join(city2))
            f.close()
            b = input("选择区列表:")
            if b == "1":
                a = 12  # 外滩
            elif b == "2":
                a = 13  # 城隍庙
            elif b == "b":
                a = 0  # 返回主菜单
            elif b == "q":
                exit()
            else:
                print("请输入正确选项:")
                a = 10
        elif a == 12:  # 外滩
            print("\n".join(shanghai1))

            f.close()
            b = input("已到3级菜单请输入b/q:")
            if b == "b":
                a = 10
            elif b == "q":
                exit()
            else:
                print("请输入正确选项:")
                a = 12
        elif a == 13:  # 城隍庙
            print("\n".join(shanghai2))
            f.close()
            b = input("已到3级菜单请输入b/q:")
            if b == "b":
                a = 10  # 返回
            elif b == "q":
                exit()
            else:
                print("请输入正确选项:")
                a = 13
else:
    print("用户锁定")





