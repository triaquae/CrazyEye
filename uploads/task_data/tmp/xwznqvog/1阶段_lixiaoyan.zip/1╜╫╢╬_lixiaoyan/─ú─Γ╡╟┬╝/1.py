#用户名:asd
#密码:123
import os
f = open("1.txt")#账号密码文件
l = open("l.txt")#锁定文件
user_name = input("请输入用户名:")
user_pwd = input("请输入密码:")
user_di = dict()
user_lock = dict()
err_pass=0#错误登录计数
err_pass1=2#输入错误达到次数  锁定

if os.path.exists("1.txt") == True and os.path.exists("l.txt") == True:#判断两个文件是否存在

    for line in f:#读取用户名密码文件
        user_l = line.strip().split(':')
        user_di[user_l[0]] = user_l[1]


    for line in l:#读取用户锁定文件 0不锁定  1锁定
        user_l = line.strip().split(':')
        user_lock[user_l[0]] = user_l[1]

    if user_lock.get(user_name) == "0":#用户不处于锁定

        if user_name in user_di.keys():#用户名存在

            while err_pass <err_pass1 :
                #print(err_pass,"a")
                err_pass = err_pass + 1#登录次数+1
                if user_pwd == user_di.get(user_name):#匹配密码
                    print("登录成功")
                    exit()
                else:#密码错误
                    #print("密码错误,请重试")
                    user_pwd=input("请重新输入密码：")
                    if err_pass==err_pass1:#锁定
                        print("用户已锁定")
                        l = open("l.txt","w+")
                        info=(user_name,":","1")
                        l.writelines(info)
                        l.close()
        else:#用户不存在
            print("用户不存在")

    elif user_lock.get(user_name) == None:
        print("用户不存在:")
    else:
        print("锁定")
else:
    print("用户文件不存在")
