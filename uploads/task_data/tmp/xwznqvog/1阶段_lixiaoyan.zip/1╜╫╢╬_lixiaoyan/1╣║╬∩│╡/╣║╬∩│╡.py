#一级菜单
menu='''
#####购物#####
1.注册
2.登录
3.退出
'''
#登录后菜单
menu1='''
1.购物记录
2.充值
3.购物
4.退出
'''
#商品列表
shop=[
    ['iphone7',6000],
    ["电脑",1500],
    ["显示器",999],
    ["英菲尼迪",290000]
]

linshi={"1":0,"2":0,"3":0,"4":0}#本次购买信息记录
filename1="_yue.txt"#生成记录用户余额的文件
filename2="_his.txt"#生成记录用户购买历史的文件


bg=0
status=0#菜单跳转
while bg==0:
    if status==0:#主菜单
        print("欢迎！")
        print(menu)
        num_menu=input("请输入数字选择:")
        if num_menu == "1":#注册
            f = open("user.txt", "a+")#a+  不存在会创建文件
            print("注册")
            print("欢迎注册:")
            user_name = input("请输入用户名:")
            user_pwd = input("请输入密码:")
            user_di = dict()
            user_f = open("user.txt")
            for line in user_f:
                user_l = line.strip().split(':')
                user_di[user_l[0]] = user_l[1]
                #    print(user_di)
            if user_name in user_di.keys():#判断用户是否存在
                print(user_name, "该用户名已占用，请重选择!")
            else:
                info = (user_name, ":", user_pwd, '\n')#写入格式
                f.writelines(info)#写入注册用户名密码
                f.close()

                fyue = open(user_name + filename1, "w+")#注册时创建用户的余额文件
                info = ("0", '\n')
                fyue.writelines(info)
                fyue.close()
                print("注册成功，请返回登录")
        elif num_menu == "2":#登录
            user_di = dict()
            f = open("user.txt", "a+")
            print("请登录：")
            user_name = input("请输入用户名:")
            user_pwd = input("请输入密码:")
            user_f = open("user.txt")
            for line in user_f:
                user_l = line.strip().split(':')
                user_di[user_l[0]] = user_l[1]
            #print(user_di.keys())
            d_user=user_name in user_di.keys()
            if d_user == True:#判断用户是否存在
                user_passwd = user_di[user_name]
                if user_passwd == user_pwd:#判断密码是否正确
                    print("登陆成功,跳转至购物界面.")
                    status=1
                else:#密码错误
                    print("用户名或密码错误!请确认")
            else:#用户不存在
                print("用户名或密码错误!请确认")


        elif num_menu == "3":#退出选项
            print("退出")
            exit()
        else:
            print("请输入正确选项!!!!")
            status=0

    elif status==1:#登录成功后菜单
        print(menu1)
        gouwu_num=input("请选择")
        if gouwu_num == "1":
            status=11#购物记录
        elif gouwu_num == "2":
            status=12#充值
        elif gouwu_num == "3":
            status=13#购物
        elif gouwu_num == "4":#退出
            ex_his = '''
            本次购买了:
            iphone7:%s
            电脑:%s
            显示器:%s
            英菲尼迪:%s
            ''' % (linshi["1"], linshi["2"], linshi["3"], linshi["4"])
            print(ex_his)
            exit()
        else:
            print("请输入正确选项")


    elif status==11:#购物历史
        touch_his=open(user_name + filename2,"a+")#历史购物记录文件  不存在则创建
        fhis = open(user_name + filename2,encoding= 'gbk').readlines()
        #fhis = open(user_name + filename2, encoding='utf-8').readlines()
        print("购物历史为://////////////////////////")
        for line in fhis:
            print(line)
        status=1#返回登录后菜单

    elif status==12:#充值
        user_yue = open(user_name + filename1).read()#获取余额，此文件会在用户注册时创建
        user_yue1 = int(user_yue)
        print(user_name, "您当前余额是：", user_yue1)
        add_m = input("请输入充值金额")
        yn_m = add_m.isdigit()
        if yn_m == True:#判断用户输入是否为数字
            add_m1 = int(add_m)#转换int
            user_yue = add_m1 + user_yue1
            user_yue1 = str(user_yue)#转换string

            print("充值完成，当前金额为：",user_yue1)

            fyue1 = open(user_name + filename1, 'w+')
            fyue1.writelines(user_yue1)
            fyue1.close()
            status=1#充值完成返回用户登录菜单
        else:#用户输入不是数字
            print("请输入正确数字")
            status=12#返回充值界面


    elif status == 13:#购物菜单
        for a, b in enumerate(shop):#输出商品列表
            a=a+1
            print(a, b[0], b[1])
        print("b","返回")
        user_yue = open(user_name + filename1).read()#读取余额
        print("当前余额为:",user_yue)
        gouwu_num=input("请选择商品")
        gouwu_max=len(shop)#获取商品列表数量
        print(gouwu_max)
        gouwu_max1=gouwu_max
        #gouwu_max1=gouwu_max-1
        print(gouwu_max,gouwu_max1)
        if gouwu_num == "b":#返回
            status=1
        elif (gouwu_num.isdigit()==True) and (int(gouwu_num) <= int(gouwu_max1)):#输入的是数字，并且在商品列表里
            #elif int(gouwu_num) <= int(gouwu_max1):
            gouwu_s = int(input("请输入购买数量"))
            gouwu_num1=int(gouwu_num)-1
            need_m=shop[gouwu_num1][1]*gouwu_s#购买商品*数量
            print("购买",  shop[gouwu_num1][0], gouwu_s, "个","需要",need_m,"元")
            yue_del=int(user_yue)-(int(shop[gouwu_num1][1])*int(gouwu_s))#计算余额是否够
            if yue_del >= 0:#余额够
                fyue1 = open(user_name + filename1, 'w+')
                fyue1.writelines(str(yue_del))#扣钱
                fyue1.close()
                fhis = open(user_name + filename2, 'a+')
                info=("购买了",shop[gouwu_num1][0]," ",str(gouwu_s),"个", '\n')
                fhis.writelines(info)#写入历史记录
                fhis.close()
                linshi[gouwu_num]=linshi[gouwu_num]+gouwu_s#记录本次购物
                #print(linshi)
            else:#余额不足
                print("余额不足！！")

        else:
            print("参数错误，请重新输入!!")

